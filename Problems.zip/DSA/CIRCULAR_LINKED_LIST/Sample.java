import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Sample {
    public static void main(String[] args) {
        List<Integer>list=new LinkedList<>(Arrays.asList(1,2,3,4));
        System.out.println(list);
    }
}
