public class countCharacter {
    public static void main(String[] arg)
    {
        String str="hello world";
        int count=0;
        for (int i = 0; i < str.length(); i++) {
            if(str.charAt(i)!=' ')
            {
                count++;
            }
        }
        System.out.println("character count is:"+count);
    }
}
