public class reverseString {
    public static void main(String[] arg) {
        String str = "grass is greener on the other side";
        String reverseStr="";
        for(int i=str.length()-1;i>=0;i--)
        {
            reverseStr=reverseStr+str.charAt(i);
        }
        System.out.println(reverseStr);
    }
}
