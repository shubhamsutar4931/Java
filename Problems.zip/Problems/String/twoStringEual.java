import java.util.Arrays;

public class twoStringEual {
    public static void main(String[] arg)
    {
        String str1="Brag";
        String str2="Grab";

        str1=str1.toLowerCase();
        str2=str2.toLowerCase();

        if(str1.length()!=str2.length())
        {
            System.out.println("not anagram/not equal");
        }
        else
        {
            char string1[]=str1.toCharArray();
            char string2[]=str2.toCharArray();

            Arrays.sort(string1);
            Arrays.sort(string2);


                if(Arrays.equals(string1,string2)==true)
                {
                    System.out.println("equal");
                }
                else {
                    System.out.println("not anagram/not equal");
                }
        }


    }
}
