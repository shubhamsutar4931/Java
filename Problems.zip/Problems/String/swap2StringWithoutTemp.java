public class swap2StringWithoutTemp {
    public static void main(String[] arg)
    {
        String str1="good";
        String str2="morning";

        str1=str1+str2;
        str2=str1.substring(0,str1.length()-str2.length());
        str1=str1.substring(str2.length());

        System.out.println("after swapping: "+str1+" "+str2);
    }
}
