public class palidromeOfString {
    public static void main(String[] arg)
    {
        String str="Nayan";
        boolean flag=true;
        str=str.toLowerCase();
        for(int i=0;i<str.length();i++)
        {
            if(str.charAt(i)!=str.charAt(str.length()-i-1))
            {
                flag=false;
                break;
            }
        }
        if(flag==true)
        {
            System.out.println("It is palidrome");
        }
        else
        {
            System.out.println("It is not palidrome");
        }
    }
}
