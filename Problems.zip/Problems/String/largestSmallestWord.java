public class largestSmallestWord {
    public static  void main(String [] arg)
    {
        String str="Hardships often prepare ordinary people for an extraordinary destiny";
        String  large="",small="",word="";
        String words[]=new String[100];
        int length=0;

        str=str+" ";
        for(int i=0;i<str.length();i++)
        {
            if(str.charAt(i)!=' ')
            {
                word=word+str.charAt(i);
            }
            else {
                words[length]=word;
                length++;
                word=" ";
            }
        }
        small=large=words[0];
        for(int i=0;i<length;i++)
        {
            if(small.length()>words[i].length())
            {
                small=words[i];
            } else if (large.length()<words[i].length())
            {
                large=words[i];
            }
        }
        System.out.println("small word:"+small);
        System.out.println("large word:"+large);

    }
}
