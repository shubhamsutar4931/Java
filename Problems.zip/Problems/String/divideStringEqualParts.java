public class divideStringEqualParts {
    public static void main(String[] arg)
    {
        String str="aaaabbbbcccc";
        int temp=0,n=3;
        int len=str.length();
        int chars=len/n;
        String equalstr[]=new String[n];
        if(len%n!=0)
        {
            System.out.println("not divisible equaly");
        }
        else
        {
            for (int i = 0; i <str.length() ; i=i+chars) {
                String part=str.substring(i,i+chars);
                equalstr[temp]=part;
                temp++;
            }
        }
        for(int i=0;i<3;i++)
        {
            System.out.println(equalstr[i]);
        }

    }
}
