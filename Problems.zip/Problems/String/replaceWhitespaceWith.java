public class replaceWhitespaceWith {
    public static void main(String[] arg)
    {
        String str="remove all white spaces";
        char ch='-';
        str=str.replace(' ',ch);
        System.out.println(str);
    }
}
