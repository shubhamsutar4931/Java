import java.util.Scanner;

public class reverseStringRecursively {
    public static void main(String[] args)
    {
        String  str;
        Scanner sc=new Scanner(System.in);
        str=sc.nextLine();
        sc.close();
        String reversed=reverseString(str);
        System.out.println(reversed);
    }
    public static String reverseString(String a)
    {
        if(a.isEmpty())
        {
            return a;
        }
        return reverseString(a.substring(1))+a.charAt(0);
    }
}
