public class smallBigPalindrome {
    public static void main(String[] args) {
        String str = "Wow you own kayak";
        String word = "", small = "", large = "";
        String words[] = new String[100];
        int temp = 0;
        str=str.toLowerCase();
        // Append a space at the end to ensure the last word is processed
        str = str + " ";

        // Extract words from the string
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != ' ') {
                word = word + str.charAt(i);
            } else {
                words[temp] = word;
                temp++;
                word = "";
            }
        }

        // Find smallest and largest palindrome
        int count = 0;
        for (int i = 0; i < temp; i++) {
            if (isPalindrome(words[i])) {
                count++;
                if (count == 1) {
                    small = large = words[i];
                } else {
                    if (words[i].length() < small.length()) {
                        small = words[i];
                    }
                    if (words[i].length() > large.length()) {
                        large = words[i];
                    }
                }
            }
        }

        if (count == 0) {
            System.out.println("No palindrome present in the string");
        } else {
            System.out.println("Smallest palindrome: " + small);
            System.out.println("Largest palindrome: " + large);
        }
    }

    // Method to check if a string is a palindrome
    public static boolean isPalindrome(String a) {
        int len = a.length();
        for (int i = 0; i < len / 2; i++) {
            if (a.charAt(i) != a.charAt(len - 1 - i)) {
                return false;
            }
        }
        return true;
    }
}
