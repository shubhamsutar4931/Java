import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class countWordFromFile {
    public static void main(String [] arg) throws IOException {
        String line;
        int count = 0;

        FileReader file = new FileReader("C://Users//DELL//OneDrive//Documents//data.txt");
        BufferedReader br = new BufferedReader(file);

        while((line = br.readLine()) != null)
        {
            String words[]=line.split(" ");
            count=count+ words.length;
        }
        System.out.println("count of words:"+count);
    }
}
