public class stringIsRotationOfOther {
    public static void main(String[] arg)
    {
        String str="abcde";
        String str1="deabd";
        if(str.length()!=str1.length())
        {
            System.out.println("second string is not rotation of string one");
        }
        else
        {
            str=str.concat(str);
            if(str.indexOf(str1)!=-1)
            {
                System.out.println("second string is rotation of string one");
            }
            else
            {
                System.out.println("second string is not rotation of string one");
            }
        }
    }
}
