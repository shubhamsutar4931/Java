public class minMaxOccurance {
    public static void main(String[] arg)
    {
        String str = "grass is greener on the other side";
        int freq[]=new int[str.length()];
        char minChar=str.charAt(0),maxChar=str.charAt(0);
        int i,j,min,max;


        //convert string into array
        char[] arr =str.toCharArray();

        //count of words
        for(i=0;i<arr.length;i++)
        {
            freq[i]=1;
            for(j=i+1;j< arr.length;j++)
            {
                if(arr[i]==arr[j]&&arr[i]!=' '&&arr[i]!='0')
                {
                    freq[i]++;
                    //visited
                    arr[j]='0';
                }
            }
        }
        min=max=freq[0];
        for (i=0;i< freq.length;i++)
        {
            if(min>freq[i]&&freq[i]!='0')
            {
                min=freq[i];
                minChar=arr[i];
            }
            else if(max<freq[i])
            {
                max=freq[i];
                maxChar=arr[i];
            }
        }
        System.out.println("minimum occurance element:"+minChar);
        System.out.println("maximum occurance element:"+maxChar);
    }
}
