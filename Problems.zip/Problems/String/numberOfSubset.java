public class numberOfSubset {
    public static void main(String[] arg) {
        String str = "fun";
        int temp = 0;
        int len=str.length();
        String subStr[] = new String[len*(len + 1) / 2];
        for (int i = 0; i < len; i++) {
            for (int j = i; j < len; j++)
            {
                 subStr[temp]=str.substring(i,j+1);
                 temp++;
            }
        }
        for (int i = 0; i <subStr.length; i++) {
            System.out.println(subStr[i]);
        }

    }
}
