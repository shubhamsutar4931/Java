public class permutationOfString {
    public static void main(String [] arg)
    {
        String str="abc";
        int len= str.length();
        System.out.println("All permutation of the string:");
        generatePermutation(str,0,len);
    }
    public static String generatePermutation(String str,int start,int end)
    {
        if (start==end-1)
        {
            System.out.println(str);
        } else
        {
            for(int i=start;i<end;i++)
            {
                str=swapString(str,start,i);
                //Recursively calling function generatePermutation() for rest of the characters
                generatePermutation(str,start+1,end);
                //Backtracking and swapping the characters again.
                str=swapString(str,start,i);
            }
        }
        return str;
    }
    public static String swapString(String a,int i,int j)
    {
        char b[]=a.toCharArray();
        char ch;
        ch=b[i];
        b[i]=b[j];
        b[j]= ch;
        return String.valueOf(b);
    }
}
