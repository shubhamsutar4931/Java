public class removeSpace {
    public static void main(String[] arg)
    {
        String str="remove all white spaces";
        str=str.replaceAll("\\s","");
        System.out.println(str);
    }
}
