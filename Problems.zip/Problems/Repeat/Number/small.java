public class small {
    public static void main(String[] args) {
        int a=10,b=11,c=12;
        int t=(a<b)?a:b;
        int s=(c<t)?c:t;
        System.out.println(s);
    }
}
