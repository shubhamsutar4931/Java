public class chartoAscii {
    public static void main(String[] args) {
        /*char c1='A';
        char c2='B';
        int a1=c1;
        int a2=c2;
        System.out.println(a1);
        System.out.println(a2);*/
        int c1='A';
        int c2='B';
        System.out.println(c1);
        System.out.println(c2);
    }
}
