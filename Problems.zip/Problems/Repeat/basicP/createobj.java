public class createobj {
    public static void main(String[] args) {
        createobj obj=new createobj();
//        obj.show(1,2);
    }
//    public static void show(int a,int b)
//    {
//        System.out.println(a+b);
//    }
    createobj()
    {
        System.out.println("hello");
    }
}
