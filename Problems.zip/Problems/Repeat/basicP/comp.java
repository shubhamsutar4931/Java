import java.util.*;

public class comp {
    public static void main(String[] args) {
        Double a=new Double(122.321);
        Long b=new Long(1456);
        System.out.println(a.equals(b));
        System.out.println(a.equals(122.321));
    }
}
