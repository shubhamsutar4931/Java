public class Aall {
    public static void main(String[] args) {
//        int n=4;
//        for(int i=1;i<=n;i++)
//        {
//            for (int j=n;j>=(n-i)+1;j--)
//            {
//                System.out.print(j+" ");
//            }
//            System.out.println();
//        }
        int n=4;
        for(int i=1;i<n;i++)
        {
            for(int j=i;j>=1;j--)
            {
                System.out.print(j+" ");
            }
            System.out.println(" ");
        }
    }
}
