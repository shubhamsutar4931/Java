public class removeWhiteSpaces {
    public static void main(String[] args) {
        String str="shubham sutar";
        char ch='-';
        str=str.replace(' ',ch);
        System.out.println(str);
    }
}
