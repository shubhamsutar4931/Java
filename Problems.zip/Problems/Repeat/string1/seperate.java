public class seperate {
    public static void main(String[] args) {
        String str="shubham";
        for (int i = 0; i < str.length(); i++) {
            System.out.print(str.charAt(i)+" ");
        }
    }
}
