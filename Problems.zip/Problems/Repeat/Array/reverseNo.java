public class reverseNo {
    public static void main(String[] args) {
        int arr1[]={1,2,3,4,5};
//        int arr2[]=new int[arr1.length];
        for(int i= arr1.length-1;i>=0;i--)
        {
//            arr2[i]=arr1[i];
            System.out.print(arr1[i]+" ");
        }

    }
}
