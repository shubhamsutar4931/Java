public class evenIndex {
    public static void main(String[] args) {
        int arr1[]={1,2,3,4,5};
        for(int i=0;i< arr1.length;i++)
        {
            if(arr1[i]%2==0)
            {
                System.out.print(arr1[i]+" ");
            }
        }
    }
}
