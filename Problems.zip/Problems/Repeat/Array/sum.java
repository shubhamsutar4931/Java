public class sum {
    public static void main(String[] args) {
        int sum=0;
        int a[]={1,2,4,2,4,5,2};
        for(int i=0;i<a.length;i++)
        {
            sum=sum+a[i];
        }
        System.out.println(sum);
    }
}
