public class createObject {
//    void show()
//    {
//        System.out.println("hello world!");
//    }

    //constructor
    createObject()
    {
        System.out.println("hello world!");
    }

    public static void main(String[] arg)
    {
        createObject obj=new createObject();
//        obj.show();

    }
}
