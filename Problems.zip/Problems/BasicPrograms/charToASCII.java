public class charToASCII {
    public static void main(String[] arg)
    {
//        char ch1='A';
//        char ch2='B';
//        int ASCII1=ch1;
//        int ASCII2=ch2;
//        System.out.println(ASCII1);
//        System.out.println(ASCII2);


        int ch1='A';
        int ch2='B';
        System.out.println(ch1);
        System.out.println(ch2);
    }
}
