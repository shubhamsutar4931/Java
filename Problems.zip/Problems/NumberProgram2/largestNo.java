public class largestNo {
    public static void main(String[] arg)
    {
        int a=18,b=11,c=12;
        int temp=(a>b)?a:b;
        int large=(temp>c)?temp:c;
        System.out.println(large);
    }
}
