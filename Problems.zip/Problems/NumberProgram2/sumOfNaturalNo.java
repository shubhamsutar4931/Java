public class sumOfNaturalNo {
    public static void main(String[] arg)
    {
        int n=5,sum=0;
        for(int i=1; i<=5;i++)
        {
            sum=sum+i;
        }
        System.out.println(sum);
    }
}
