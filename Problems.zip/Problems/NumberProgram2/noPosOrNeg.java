public class noPosOrNeg {
    public static void main(String[] arg)
    {
        int n=000;
        if(n>0)
        {
            System.out.println("positive");
        }
        else if(n<0)
        {
            System.out.println("negative");
        }
        else {
            System.out.println("zero");
        }
    }
}
