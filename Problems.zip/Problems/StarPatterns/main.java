public class main {
    public static void main(String[] arg)
    {
//        RightTriangleStarPattern1(4);
//        LeftTrianglePattern2(5);
//        PyramidPattern3(5);
//        DiamondPattern4(5);
//        DownwardTriangleStarPattern5(5);
//        ReversePyramidPattern7(5);
//        RightPascalTriangle9(5);
//        LeftPascalTrianglePattern10(5);
//        TrianglePattern14(5);
        ReverseTrianglePattern15(5);
//        NumberPattern1(5);


    }



//    static void RightTriangleStarPattern1(int n)
//        {
//            for(int row=1;row<=n;row++)
//            {
//                for(int col=1;col<=row;col++)
//                {
//                    System.out.print("* ");
//                }
//                System.out.println();
//            }
//        }

    //    LeftTrianglePattern
//    static void LeftTrianglePattern2(int n)
//    {
//        for(int row=1;row<=n;row++)
//        {
//            for(int col=2*(n-row);col>=1;col--)
//            {
//                System.out.print(" ");
//            }
//            for(int col=1;col<=row;col++)
//            {
//                System.out.print("* ");
//            }
//            System.out.println();
//        }
//    }


//    PyramidPattern
//    static void PyramidPattern3(int n)
//    {
//        for(int row=1;row<=n;row++)
//        {
//            for(int col=(n-row);col>=1;col--)
//            {
//                System.out.print(" ");
//            }
//            for(int col=1;col<=row;col++)
//            {
//                System.out.print("* ");
//            }
//            System.out.println();
//        }
//    }


//    DiamondPattern
//            static void DiamondPattern4(int n)
//            {
//                for(int row=1;row<=n;row++)
//                {
//                    for(int col=(n-row);col>=1;col--)
//                    {
//                        System.out.print(" ");
//                    }
//                    for(int col=1;col<=row;col++)
//                    {
//                        System.out.print("* ");
//                    }
//                    System.out.println();
//                }
//                for(int row=1;row<=n;row++)
//                {
//                    for(int col=1;col<=row;col++)
//                    {
//                        System.out.print(" ");
//                    }
//                    for(int col=1;col<=n-row;col++)
//                    {
//                        System.out.print("*"+" ");
//                    }
//                    System.out.println();
//                }
//
//            }



//    ReversePyramidPattern
//    static void ReversePyramidPattern7(int n)
//    {
//        for(int row=1;row<=n;row++)
//        {
//            for(int col=1;col<=row;col++)
//            {
//                System.out.print(" ");
//            }
//            for(int col=1;col<=(n-row)+1;col++)
//            {
//                System.out.print("*"+" ");
//            }
//            System.out.println();
//        }
//    }



//    DownwardTriangleStarPattern
//    static void DownwardTriangleStarPattern5(int n)
//
//        for(int row=1;row<=n;row++)
//        {
//            for(int col=1;col<=(n-row)+1;col++)
//            {
//                System.out.print("* ");
//            }
//            System.out.println();
//        }
//    }



//    RightPascalTriangle9
//    static void RightPascalTriangle9(int n)
//    {
//        for(int row=1;row<=n;row++)
//        {
//            for(int col=1;col<=row;col++)
//            {
//                System.out.print("* ");
//            }
//            System.out.println();
//        }
//        for(int row=1;row<=n;row++) {
//
//            for (int col = 1; col <= (n - row) ; col++) {
//                System.out.print("* ");
//            }
//            System.out.println();
//        }
//
//    }


//    LeftPascalTrianglePattern
//        static void LeftPascalTrianglePattern10(int n)
//        {
//            for(int row=1;row<=n;row++)
//            {
//                for(int col=2*(n-row);col>=1;col--)
//                {
//                    System.out.print(" ");
//                }
//                for(int col=1;col<=row;col++)
//                {
//                    System.out.print("* ");
//                }
//                System.out.println();
//            }
//            for(int row=1;row<=n;row++)
//            {
//                for(int col=1;col<=2*row;col++)
//                {
//                    System.out.print(" ");
//                }
//                for(int col=1;col<=(n-row);col++)
//                {
//                    System.out.print("* ");
//                }
//                System.out.println();
//            }
//        }

//    TrianglePattern
//    static void TrianglePattern14(int n)
//    {
//        for(int row=1;row<=n;row++)
//        {
//            for(int col=row;col<n;col++)
//            {
//                System.out.print(" ");
//            }
//            for(int col=1;col<=(2*row-1);col++)
//            {
//                if(col==1||col==2*row-1||row==n)
//                {
//                    System.out.print("*");
//                }
//                else
//                {
//                    System.out.print(" ");
//                }
//
//            }
//            System.out.println();
//        }

//    ReverseTrianglePattern
    static void ReverseTrianglePattern15(int n)
    {
        for(int row=n;row>=1;row--)
        {
            for(int col=row;col<n;col++)
            {
                System.out.print(" ");
            }
            for(int col=1;col<=(2*row-1);col++)
            {
                if(col==1||col==2*row-1||row==n)
                {
                    System.out.print("*");
                }
                else
                {
                    System.out.print(" ");
                }

            }
            System.out.println();
        }
    }



//    static void NumberPattern1(int n)
//    {
//        for(int i=1;i<=n;i++)
//        {
//            for(int j=1;j<=i;j++)
//            {
//                System.out.print(j+" ");
//            }
//            System.out.println();
//        }
//    }
}

