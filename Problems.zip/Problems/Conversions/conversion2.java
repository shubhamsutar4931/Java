public class conversion2 {
    public static void main(String[] args) {
//       11)string to char
//        String str="shubham";
//        char c= str.charAt(0);
//        System.out.println(c);

//        12)char to string
//        char c='a';
//        String  s=String.valueOf(c);
//        System.out.println(s);

//        13)string to object
//            String  s="shubham";
//            Object obj=s;
//        System.out.println(obj);

//        15)int to long
//        int i=100;
//        long l=i;
//        System.out.println(l);

//        16)long to int
//        long l=100;
//        int i=(int)l;
//        System.out.println(i);

//        19)char to int
//        char c='a';
//        int i=c;
//        System.out.println(i);

//        20)int to char
        int i=97;
        char c=(char) i;
        System.out.println(c);
    }
}
