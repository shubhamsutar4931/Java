public class conversion3 {
    public static void main(String[] args) {
//        25)binary to decimal
//        String bin="1010";
//        int dec=Integer.parseInt(bin,2);
//        System.out.println(dec);

//        26)decimal to binary
//        String  bin=Integer.toBinaryString(10);
//        System.out.println(bin);

//        27)hexa to decimal
//        String hex="a";
//        int dec=Integer.parseInt(hex,16);
//        System.out.println(dec);

//        28)decimal to hexa
//        String  hexa=Integer.toHexString(15);
//        System.out.println(hexa);

//        29)octate to decimal
//        String oct="121";
//        int dec=Integer.parseInt(oct,8);
//        System.out.println(dec);

//        30)decimal to octate
        String  oct=Integer.toOctalString(15);
        System.out.println(oct);
    }
}
