public class practice {
    public static void main(String[] args) {
        // double num1 = 33.4552154;
        // float num2 = 43.0215212f;
        // double result = num1 + num2;
        // System.out.println(result);
        // char c = 'a';
        // c++;
        // System.out.println(c);

        // type casting
        int a = 2;
        byte b = 123;
        a = (byte) b;
        System.out.println(a);
    }
}
/*
 * public class practice {
 * public static void main(String[] args) {
 * String address = "Delhi, India";
 * 
 * if (address.endsWith("India")) {
 * if (address.contains("Meerut")) {
 * System.out.println("Your city is Meerut");
 * } else if (address.contains("Noida")) {
 * System.out.println("Your city is Noida");
 * } else {
 * System.out.println(address.split(",")[0]);
 * }
 * } else {
 * System.out.println("You are not living in India");
 * }
 * }
 * }
 */