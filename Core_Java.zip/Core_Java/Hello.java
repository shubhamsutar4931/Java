//variables
/*public class Hello
{  
    static int m=100;//static variable  
    void method()  
    {    
        int n=90;//local variable    
    }  
    public static void main(String args[])  
    {  
        int data=50;//instance variable    
    }  
}//end of class*/

// public class Hello {
//       public static void main(String args[]) {
//             int num1 = 20;
//             int num2 = 70;
//             int result = num1 + num2;
//             System.out.println(result);
//             String name = "shubham";
//             System.out.println(name);
//       }
// }

//Data types
// public class Hello
// {
//       public static void main(String[] args) 
//       {
//          int num1=10;
//          byte b= 21;
//          short sh=20;
//          long l=12312l;

//          float f=5.8f;
//          double d=8.211;

//          char c='s';

//          boolean bo=true;

//       }
// }

// literals
// public class Hello {
//       public static void main(String[] args) {
//             int num1 = 1000;
//             System.out.println(num1);
//             double num2 = 10e10;
//             System.out.println(num2);
//             char c = 'a';
//             c++;
//             System.out.println(c);

//       }
// }

//Type casting
// public class Hello {

//       public static void main(String[] args) {
//             // byte b = 127;
//             // int a = b;   #implecit conversion
//             // System.out.println(a);

//             int a = 257;
//             byte b = (byte) a;
//             System.out.println(b);

//             float f = 1.23f;
//             int c = (int) f;
//             System.out.println(c);

//       }
// }
/*class Hello {
      public static void main(String[] args) {
            // Overflow
            int a = 130;
            byte b = (byte) a;
            System.out.println(a);
            System.out.println(b);
      }
}*/

// Type Proportion
public class Hello {

public static void main(String[] args) {
byte a = 10;
byte b = 20;
int result = a * b;
System.out.println(result);
}
}