// Assigment operator
// public class Operaters {
// public static void main(String[] args) {
// int num1 = 10;
// // int num2 = 30;
// // int result = num1 + num2;

// // num1 = num1 + 2;

// num1 += 2;
// System.out.println(num1);

// }

// }

// Relational operators
public class Operaters {
    public static void main(String[] args) {
        int x = 4;
        int y = 5;

        double a = 2.4;
        double b = 3.2;
        boolean result = !(a < b);
        System.out.println(result);
        System.out.println(~x);
        System.out.println(x << 2); // left shift operator
        System.out.println(x >> 2); // right shift operator
    }
}