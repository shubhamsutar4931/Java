package Encapsulation;

class practice {
    public static void main(String[] args) {
        // creating instance of the encapsulated class
        student s = new student();
        // setting value in the name member
        s.setName("vijay");
        // getting value of the name member
        System.out.println(s.getName());
    }
}